# SurakshaDrishti AI - 35% MVP

A simplified college-project milestone of SurakshaDrishti AI.

## Included
- Webcam/video input
- YOLOv8 person detection
- Person counting
- Basic alert event
- SQLite storage
- FastAPI backend
- Simple browser dashboard

## Architecture
Camera -> OpenCV -> YOLOv8 -> Event -> SQLite -> FastAPI Dashboard

## Run

    pip install -r requirements.txt
    python backend/main.py

Open http://127.0.0.1:8000

For webcam detection, open another terminal:

    python ai_engine/person_detection.py

The Ultralytics package can download yolov8n.pt automatically on first use.

## Project status
This repository intentionally contains the core MVP milestone rather than the complete feature set of the full project.
