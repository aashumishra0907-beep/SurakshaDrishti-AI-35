import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from database.database import init_db, get_events, add_event

app = FastAPI(title="SurakshaDrishti AI - 35% MVP")
init_db()

@app.get("/api/status")
def status():
    return {
        "system": "online",
        "project": "SurakshaDrishti AI",
        "milestone": "35%"
    }

@app.get("/api/events")
def events():
    return get_events()

@app.post("/api/test-alert")
def test_alert():
    add_event("PERSON_DETECTED", 1, "MEDIUM")
    return {"message": "Test alert recorded"}

@app.get("/", response_class=HTMLResponse)
def dashboard():
    html = """<!DOCTYPE html>
<html>
<head>
<title>SurakshaDrishti AI - 35% MVP</title>
<style>
body { font-family: Arial; margin: 40px; background: #f4f6f8; }
.card { background: white; padding: 20px; margin-bottom: 20px; border-radius: 10px; }
button { padding: 10px 16px; cursor: pointer; }
pre { background: #111; color: #eee; padding: 15px; }
</style>
</head>
<body>
<h1>SurakshaDrishti AI</h1>
<p>Railway Crowd & Safety Monitoring - 35% MVP</p>
<div class="card">
<h2>System Status</h2>
<p id="status">Loading...</p>
<button onclick="testAlert()">Create Test Alert</button>
</div>
<div class="card">
<h2>Recent Events</h2>
<pre id="events">Loading...</pre>
</div>
<script>
async function load() {
    const status = await fetch('/api/status').then(r => r.json());
    document.getElementById('status').textContent =
        status.system + " | Milestone: " + status.milestone;
    const events = await fetch('/api/events').then(r => r.json());
    document.getElementById('events').textContent =
        JSON.stringify(events, null, 2);
}
async function testAlert() {
    await fetch('/api/test-alert', {method: 'POST'});
    load();
}
load();
setInterval(load, 3000);
</script>
</body>
</html>"""
    return HTMLResponse(html)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
