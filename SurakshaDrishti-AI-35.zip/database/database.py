import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "events.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS events ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "event_type TEXT NOT NULL,"
            "person_count INTEGER NOT NULL,"
            "severity TEXT NOT NULL,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)"
        )
        conn.commit()

def add_event(event_type, person_count, severity):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO events(event_type, person_count, severity) VALUES (?, ?, ?)",
            (event_type, person_count, severity)
        )
        conn.commit()

def get_events():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT 50"
        ).fetchall()
        return [dict(row) for row in rows]
