# SurakshaDrishti AI - 35% Milestone

## Included
- AI person detection
- Webcam input
- Person count
- Basic alert event
- SQLite storage
- FastAPI API
- Simple web dashboard

## Planned for later milestones
- Multi-camera management
- Advanced tracking
- SOS workflow
- Authority dispatch workflow
- WebSocket live notifications
- Reports/export
- Heatmap
- Advanced activity detection
- Production deployment

This is a deliberately reduced MVP milestone of the larger project.
